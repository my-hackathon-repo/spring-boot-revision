package com.dreamweaver.spring_revision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRevisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
