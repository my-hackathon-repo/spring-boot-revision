package com.dreamweaver.spring_revision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRevisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRevisionApplication.class, args);
	}

}
